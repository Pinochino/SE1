package a1_2201040165;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Engine {

    private List<Doc> docs;

    public Engine() {
        this.docs = new ArrayList<>();
    }

    public int loadDocs(String dirname) {
        docs.clear();
        File folder = new File(dirname);

        if (!folder.exists() || !folder.isDirectory()) {
            return 0;
        }

        File[] files = folder.listFiles(file -> file.isFile() && file.getName().endsWith(".txt"));

        if (files == null || files.length == 0) {
            return 0;
        }

        for (File file : files) {
            try {

                String content = new String(Files.readAllBytes(Paths.get(file.getAbsolutePath())));
                docs.add(new Doc(content));
            } catch (IOException e) {
                System.err.println("Failed to load file: " + file.getName());
            }
        }

        return docs.size();
    }

    public Doc[] getDocs() {
        return docs.toArray(new Doc[0]);
    }

    public List<Result> search(Query query) {
        List<Result> results = new ArrayList<>();

        docs.forEach(doc -> {
            List<Match> matches = query.matchAgainst(doc);
            if (!matches.isEmpty()) {
                results.add(new Result(doc, matches));
            }
        });

        results.sort(Comparator.naturalOrder());

        return results;
    }

    public String htmlResult(List<Result> results) {
        StringBuilder html = new StringBuilder();
        results.forEach(result -> html.append(result.htmlHighlight()));
        return html.toString();
    }
}
