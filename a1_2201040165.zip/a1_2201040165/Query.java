package a1_2201040165;
import java.util.*;

public class Query {
    private List<Word> keywords;

    public Query(String searchPhrase) {
        this.keywords = new ArrayList<>();
        List<Word> words = Doc.parseWords(searchPhrase);
        for (Word word : words) {
            if (word.isKeyword())
                keywords.add(word);
        }
    }

    public List<Word> getKeywords() {
        return keywords;
    }

    public List<Match> matchAgainst(Doc d) {
        List<Match> matches = new ArrayList<>();


        List<Word> allText = new ArrayList<>();
        if (d.getTitle() != null) {
            allText.addAll(d.getTitle());
        }
        if (d.getBody() != null) {
            allText.addAll(d.getBody());
        }

        if (allText.isEmpty()) {
            System.out.println("Doc contains no words");
            return matches;
        }


        for (Word keyword : keywords) {
            int firstIndex = allText.indexOf(keyword);
            if (firstIndex != -1) {
                long freq = allText.stream().filter(word -> word.equals(keyword)).count();
                matches.add(new Match(d, keyword, (int) freq, firstIndex));
            }
        }

        matches.sort(Comparator.naturalOrder());
        return matches;
    }
}



