package a1_2201040165;

import java.util.*;

public class Result implements Comparable<Result> {
    private Doc doc;
    private List<Match> matches;

    public Result(Doc d, List<Match> matches) {
        this.doc = d;
        this.matches = matches;
    }

    public List<Match> getMatches() {
        return matches;
    }

    public int getTotalFrequency() {
        int totalFreq = 0;
        for (Match match : matches) {
            totalFreq += match.getFreq();
        }
        return totalFreq;
    }

    public double getAverageFirstIndex() {
        int sumFirstIndex = 0;
        for (Match match : matches) {
            sumFirstIndex += match.getFirstIndex();
        }
        return (double) sumFirstIndex / matches.size();
    }

    public String htmlHighlight() {
        List<Word> titleWord = doc.getTitle();
        for (int i = 0; i < titleWord.size(); i++) {
            for (Match match : matches) {
                if (titleWord.get(i).equals(match.getWord())) {
                    titleWord.set(i, doc.parseWord( titleWord.get(i).getPrefix() + "<u>"  + titleWord.get(i).getText() + "</u>" + titleWord.get(i).getSuffix()));
                }
            }
        }
        List<Word> bodyWord = doc.getBody();
        for (int i = 0; i < bodyWord.size(); i++) {
            for (Match match : matches) {
                if (bodyWord.get(i).equals(match.getWord())) {
                    bodyWord.set(i, doc.parseWord(bodyWord.get(i).getPrefix() + "<b>" + bodyWord.get(i).getText() + "</b>" + bodyWord.get(i).getSuffix()));
                }
            }
        }
        String titleString = "<h3>";
        for (int i = 0; i < titleWord.size(); i++) {
            if (i == titleWord.size() - 1) {
                titleString += titleWord.get(i).getRawText() + "</h3>";
            } else {
                titleString += titleWord.get(i).getRawText() + " ";
            }
        }
        String bodyString = "<p>";
        for (int i = 0; i < bodyWord.size(); i++) {
            if (i == bodyWord.size() - 1) {
                bodyString += bodyWord.get(i).getRawText() + "</p>";
            } else {
                bodyString += bodyWord.get(i).getRawText() + " ";
            }
        }
        return titleString + bodyString;

    }
    @Override
    public int compareTo(Result o) {
        if (this.getMatches().size() != o.getMatches().size()) {
            return Integer.compare(o.getMatches().size(), this.getMatches().size());
        }
        if (this.getTotalFrequency() != o.getTotalFrequency()) {
            return Integer.compare(o.getTotalFrequency(), this.getTotalFrequency());
        }
        return Double.compare(this.getAverageFirstIndex(), o.getAverageFirstIndex());
    }


    public Doc getDoc() {
        return doc;
    }
}

