package a1_2201040165;



public class Match implements Comparable<Match> {
    private int freq;
    private int firstIndex;
    private Word w;
    private Doc d;

    public Match(Doc d, Word w, int freq, int firstIndex) {
        this.freq = freq;
        this.firstIndex = firstIndex;
        this.w = w;
        this.d = d;
    }

    public Word getWord() {
        return w;
    }

    public Doc getDoc() {
        return d;
    }

    public int getFreq() {
        return freq;
    }
    public int getFirstIndex(){
        return firstIndex;
    }

    @Override
    public int compareTo(Match o) {
        return Integer.compare(this.firstIndex, o.firstIndex);
    }

}



