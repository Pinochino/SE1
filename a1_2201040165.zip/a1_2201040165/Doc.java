package a1_2201040165;

import java.util.ArrayList;
import java.util.List;

public class Doc {
    private List<Word> title;
    private List<Word> body;

    public Doc(String content) {
        if (!content.contains("\n") && !content.isEmpty()) {
            title = parseWords(content);
        }
        if (content.contains("\n")) {
            String[] lines = content.split("\n", 2);
            title = parseWords(lines[0]);
            body = parseWords(lines[1]);
        }
    }


    public static List<Word> parseWords(String line) {
        List<Word> words = new ArrayList<>();
        StringBuilder wordBuffer = new StringBuilder();


        for (int i = 0; i < line.length(); i++) {
            char currentChar = line.charAt(i);


            if (Character.isWhitespace(currentChar)) {

                if (wordBuffer.length() > 0) {
                    words.add(Word.createWord(wordBuffer.toString()));
                    wordBuffer.setLength(0);
                }
            } else {

                wordBuffer.append(currentChar);
            }
        }


        if (wordBuffer.length() > 0) {
            words.add(Word.createWord(wordBuffer.toString()));
        }

        return words;
    }
    public static Word parseWord(String line) {
        String trimmedLine = line.trim();
        Word word =  Word.createWord(line.trim());

        return word;
    }

    public List<Word> getTitle() {
        return title;
    }

    public List<Word> getBody() {
        return body;
    }

    public boolean equals(Object o){
        if (this == o) {
            return true;
        }
        else if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        Doc d = (Doc) o;
        return this.getTitle() == ((Doc) o).getTitle() && this.getBody() == ((Doc) o).getBody();
    }
}


