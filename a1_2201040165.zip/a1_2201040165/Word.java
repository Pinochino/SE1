package a1_2201040165;

import java.io.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class Word {
    public static Set<String> stopWords;
    private String prefix;
    private String suffix;
    private String text;
    private String rawText;

    public Word() {
    }

    public Word(String prefix, String text, String suffix) {
        this.prefix = prefix;
        this.text = text;
        this.suffix = suffix;
        this.rawText = prefix + text + suffix;
    }

    public String getText() {
        return text;
    }

    public String getPrefix() {
        return prefix;
    }

    public String getSuffix() {
        return suffix;
    }

    public static String extractPrefix(String rawText) {
        int i = 0;
        while (i < rawText.length() && !Character.isLetterOrDigit(rawText.charAt(i))) {
            i++;
        }
        return rawText.substring(0, i);
    }

    private static String extractSuffix(String rawText) {
        int i = rawText.length() - 1;
        while (i > 0 && !Character.isLetterOrDigit(rawText.charAt(i))) {
            i--;
        }
        if (rawText.endsWith("'s") || rawText.endsWith("'d")) {
            return rawText.substring(rawText.length() - 2);
        }
        return rawText.substring(i + 1);
    }

    private static String extractText(String rawText) {
        if (!rawText.isEmpty()) {
            int numPreFix = extractPrefix(rawText).length();
            int numSuffix = extractSuffix(rawText).length();
            return rawText.substring(numPreFix, rawText.length() - numSuffix);
        }
        return "";
    }
    public boolean isKeyword() {

        if (this.text.matches("[A-Za-z'-]+")
                && (this.prefix.isEmpty() || this.prefix.matches("^[^a-zA-Z0-9 ]+$"))
                && (this.suffix.isEmpty() || this.suffix.matches("^[^a-zA-Z0-9 ]+$") || rawText.endsWith("'s") || rawText.endsWith("'d") )) {
            for (String word : stopWords) {
                if (rawText.toLowerCase().equals(word)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public boolean equals(Object o ) {
        Word w = (Word) o;
        return this.text.toLowerCase().trim().equals(w.text.toLowerCase().trim());
    }

    @Override
    public String toString() {
        return rawText;
    }

    public static Word createWord(String rawText) {


        int numPreFix = extractPrefix(rawText).trim().length();
        int numSuffix = extractSuffix(rawText).trim().length();

        String prefix = extractPrefix(rawText);
        if (rawText.length() - numPreFix > 0 && numPreFix != 0){
            rawText = rawText.substring(numPreFix - 1);
        }
        String suffix = extractSuffix(rawText);
        if (rawText.length() - numSuffix > 0 && numSuffix != 0){
            rawText = rawText.substring(0, rawText.length() - numSuffix );
        }
        String text = extractText(rawText);

        if (text.matches("[A-Za-z'-]+")
                && !suffix.matches("[a-zA-Z]+([0-9][a-zA-Z]+)*")
                && !prefix.matches("[a-zA-Z]+([0-9][a-zA-Z]+)*")) {
            return new Word(prefix, text, suffix);
        } else return new Word("", prefix + text + suffix, "");
    }

    public static boolean loadStopWords(String fileName)  {
        stopWords = new HashSet<>();
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                String[] lineWords = line.split("\\s+");
                for (String word : lineWords) {
                    stopWords.add(word);
                }
            }
            return true;
        }catch (FileNotFoundException e){

        } catch (IOException e) {

        }
        return false;
    }

    public String getRawText() {
        return rawText;
    }
}








